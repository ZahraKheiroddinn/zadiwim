from django.shortcuts import render, redirect, get_object_or_404
#from cart.forms import CartAddProductForm
from django.contrib.auth.decorators import login_required
# Create your views here.
from requests import Session
from orders.models import Order,OrderItem
from .conection import holoo
from shop.models import Product,Category, Brand,Janbi
from .loadData import *
from django.core.files.storage import default_storage
from .models import Price_factor
def holoo_controler (request):

    return render(request, 'holoo/control.html', { })
def factor_process(request):
    order_id = 26 #request.session.get('order_id')
    order = get_object_or_404(Order, id=order_id)
    total_cost = order.get_total_cost()
    fitme= OrderItem.objects.filter(order = order)
    detailinfo= []#[{'ProductErpCode': 'bBAHNA5IdgF4dh4O', 'few': 2, 'price': 500, 'levy': 0, 'scot': 0}, {'ProductErpCode': 'bBAHNA5IZkh7QB4O', 'few': 3, 'price': 70000, 'levy': 0, 'scot': 0}]
    for itme in fitme:
        x = {
        "ProductErpCode": itme.ProductErpCode,
        "few": itme.quantity,
        "price": float(itme.price),
        "levy": 0,
        "scot": 0

        }
        detailinfo.append(x)

    print(detailinfo)
    code = order_id
    h = holoo.Holoo()
    new_invoice = h.post_invoice(code, detailinfo)
    print(new_invoice)
    if 'Success' in new_invoice:
        test = new_invoice['Success']
        order.Code = test['Code']
        order.ErpCode = test[ 'ErpCode']
        order.save()
        return redirect('payment:done')
    else:
        order.braintree_id = 'این فاکتور در برنامه هلو دخیره نشده'
        order.save()
        return redirect('payment:done')

def get_product (request):

    cat = get_object_or_404(Category, id = 1)
    brand = get_object_or_404(Brand, id = 1)
    janbi = get_object_or_404(Janbi, id = 1)
    h = holoo.Holoo()
    all_productS = Product.objects.all()
    list = []
    for i in all_productS:
        code = i.codenum
        list.append(code)

    all_product = h.get_all_products()
    for i in all_product:

        itemcode = i["Code"]

        if itemcode in list:
            pass

        else:
            new_pro = Product(category = cat,Brand = brand, Janbi = janbi,
            name = i['Name'], slug = i['ErpCode'],  codenum = itemcode,description=str(i['MainGroupName'])+'  '+str(i['SideGroupName']), baseprice = i['SellPrice'], number= i['Few']  )
            new_pro.save()

    return redirect('holoo:holoo_controler')

def update_product (request):
    h = holoo.Holoo()
    all_product = h.get_all_products()
    for i in all_product:

        itemcode = i["Code"]
        pro = get_object_or_404(Product, codenum = itemcode)
        pro.box = i['Few']
        #pro = Product( name = i['Name'], slug = i['ErpCode'],description=str(i['MainGroupName'])+'  '+str(i['SideGroupName']), baseprice = i['SellPrice'],box = i['Few'] )
        pro.save()
    return redirect('holoo:holoo_controler')

def pull_product (request):

    h = holoo.Holoo()
    test = h.get_product()
    print(test)
    return redirect('holoo:holoo_controler')

def upload_data (request):
    if request.FILES:
        imagefile =request.FILES['excel_file']
        file_name=default_storage.save(imagefile.name, imagefile)
    factor=Price_factor.objects.latest('id')
    retail = factor.retail
    wholesale = factor.wholesale
    try:
        sheets = load_data_from_excel(file_name)
        list = sheets[0]
        items = list['items']
        for item in items:
            try:
                pro = get_object_or_404(Product, codenum = item['codenum'])
            except:
                continue

            if retail > 0:
                x =item['price']
                m = (retail * x)/100
                price = x + m
                pro.baseprice = price
                if wholesale < 0:

                    m = (abs(wholesale) * x)/100
                    price = x - m
                    pro.wholesale_price = price
                else:
                    m = (wholesale * x)/100
                    price = x + m
                    pro.wholesale_price = price

            else:
                m = (abs(retail) *x)/100
                price = x - m
                pro.baseprice = price



            pro.save()

    except Exception as e:
        print(str(e))
    return redirect("holoo:holoo_controler")