from django.db import models

# Create your models here.
class Price_factor (models.Model):
    retail = models.IntegerField(default = 0)
    wholesale = models.IntegerField(default = 0)
    class Meta:
        verbose_name = 'ضرایب قیمت در اکسل'
        verbose_name_plural =  'ضرایب قیمت در اکسل'
