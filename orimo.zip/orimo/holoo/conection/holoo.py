import json
import requests
from datetime import datetime


class Holoo:
    def set_headers(self):
        return {"Content-Type": "application/json",
                     "Authorization": self.login()}

    def login(self):
        headers = {"Content-Type": "application/json",
                     "Authorization": "Token"}
        url = 'http://2.186.13.120:8080/TncHoloo/api/Login'
        data = {"userinfo": {"username": "WEB",
                             "userpass": "MTIzNA==",
                             "dbname": "Holoo2"}}
        response = requests.post(url, json=data, headers=headers)
        res_json = json.loads(response.text)
        if res_json["Login"].get('State') is True:
            return res_json["Login"].get('Token')

    def get_product(self, code):
        url = 'http://2.186.13.120:8080/TncHoloo/api/Product'
        data = {"code": code}

        response = requests.get(url, params=data, headers=self.set_headers())
        res_json = json.loads(response.text)
        product = res_json['product']
        return product

    def get_all_products(self):
        url = 'http://2.186.13.120:8080/TncHoloo/api/Product'
        data = {}

        response = requests.get(url, json=data, headers=self.set_headers())
        res_json = json.loads(response.text)
        products = res_json['product']
        return products

    def post_invoice(self, code, detailinfo):
        url = 'http://2.186.13.120:8080/TncHoloo/api/Invoice/Invoice'

        invoice_price = 0
        for i in detailinfo:
            invoice_price += i['price']*i['few']
        data = {
            "invoiceinfo": {
                "id": '99{}'.format(code),
                "type": 1,
                "customererpcode": "bBAPOQ5Icg0=",
                "date": datetime.today().strftime('%Y-%m-%d'),
                "time": datetime.today().strftime('%H:%M'),
                "bank": invoice_price,
                "banksarfasl": "10200010001",
                "nesiyeh": 0,
                "discount": 0,
                "detailinfo": detailinfo
            }
        }

        response = requests.post(url, data=str(data), headers=self.set_headers())
        res_json = json.loads(response.text)
        return res_json
