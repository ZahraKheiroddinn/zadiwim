from django.contrib import admin
from .models import Price_factor

# Register your models here.
@admin.register(Price_factor)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ['retail', 'wholesale']
