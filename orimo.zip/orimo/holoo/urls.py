from django.urls import path
from . import views
app_name = 'holoo'
urlpatterns = [
    path('', views.holoo_controler, name='holoo_controler'),
    path('get_product', views.get_product, name='get_product'),
    path('update_product', views.update_product, name='update_product'),
    path('pull_product', views.pull_product, name='pull_product'),
    path('process/', views.factor_process, name='process'),
    path('upload/', views.upload_data, name="upload_data"),


]
