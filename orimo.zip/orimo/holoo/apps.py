from django.apps import AppConfig


class HolooConfig(AppConfig):
    name = 'holoo'
