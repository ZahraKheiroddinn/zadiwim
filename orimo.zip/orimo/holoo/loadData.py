import pandas as pd
import numpy as np
from django.conf import settings
import os, math
from datetime import date

def load_data_from_excel(file_name):

    #TODO when Django runs this line can be deleted and substitued by settins.BASE_DIR
    BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

    xl = pd.ExcelFile(BASE_DIR + '\\media' +"\\" + file_name)

    sheets = []
    for sheet in xl.sheet_names:

        df = xl.parse(sheet)
        sheet_instance = {}
        table = {'table_name' : df.columns.values[0].replace(" ", "")}
        items = []

        #date = df.columns.values[1].date()
        for i in df.index:
            if i > 0 and df.iat[i,1] is not np.nan:
                item_instance = {}

                item_instance['name'] = df.iat[i,0]
                item_instance['codenum'] = df.iat[i,1]
                item_instance['price'] = df.iat[i,2]

                items.append(item_instance)
        sheet_instance['items'] = items
        sheets.append(sheet_instance)

    return sheets

if __name__ == '__main__':
    sheets = load_data_from_excel("file_name")
    print(sheets)
