from django.db import models
from django.urls import reverse

# Create your models here.
class carbrand (models.Model):
    name = models.CharField(max_length=200,db_index=True)
    class Meta:
        ordering = ('name',)
        verbose_name = 'شرکت خودرو '
        verbose_name_plural = 'شرکت های خودرو'
    def __str__(self):
        return self.name
class Category(models.Model):
    carcompany = models.ForeignKey(carbrand,default=1,on_delete=models.CASCADE)
    name = models.CharField(max_length=200,db_index=True)
    image =models.ImageField (upload_to='products',blank=True)
    slug = models.SlugField(max_length=200,unique=True)
    class Meta:
        ordering = ('name',)
        verbose_name = 'مدل خودرو'
        verbose_name_plural = 'مدل های خودرو'
    def __str__(self):
        return self.name
    def get_absolute_url(self):
        return reverse('shop:product_list_by_category',args=[self.slug, 'car'])
class Brand(models.Model):
    name = models.CharField(max_length=200, db_index=True)
    slug = models.SlugField(max_length=200, db_index=True)
    description = models.TextField(null = True, blank=True)
    image = models.ImageField(upload_to='products/brand/',blank=True)
    class Meta:
        ordering = ('name',)
        verbose_name = 'brand'
    def __str__(self):
        return self.name
    def get_absolute_url(self):
        return reverse('shop:product_list_by_category',args=[self.slug, 'brand'])
class Janbi(models.Model):
    name = models.CharField(max_length=200, db_index=True)
    slug = models.SlugField(max_length=200, db_index=True)
    class Meta:
        ordering = ('name',)
        verbose_name = 'janbi'
    def __str__(self):
        return self.name
    def get_absolute_url(self):
        return reverse('shop:product_list_by_category',args=[self.slug, 'janbi'])
class Product(models.Model):

    category = models.ForeignKey(Category,related_name='products',on_delete=models.CASCADE)
    Brand = models.ForeignKey(Brand,on_delete=models.CASCADE)
    Janbi = models.ForeignKey(Janbi,on_delete=models.CASCADE)
    name = models.CharField(max_length=200, db_index=True)
    slug = models.SlugField(max_length=200, db_index=True)
    codenum = models.CharField(max_length=200)
    country = models.CharField(max_length=50,null = True, blank=True)
    size = models.CharField(max_length=50,null = True, blank=True)
    image = models.ImageField(upload_to='products/%Y/%m/%d',null = True, blank=True)
    description = models.TextField(null = True, blank=True)
    baseprice=models.IntegerField(default = 0)
    discount=models.IntegerField(default = 0)
    price = models.IntegerField(default = 0)
    wholesale_price =models.IntegerField(default = 0)
    box = models.IntegerField(default = 0)
    number_in_box=models.IntegerField(default = 1)
    number =models.IntegerField(default = 0)
    available = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    def save(self, *args, **kwargs):
        if self.discount == 0 or self.discount > 100:
            self.price = self.baseprice
            self.number = self.box * self.number_in_box

            super(Product, self).save(*args, **kwargs)
        else:
            x=100- self.discount
            y = x * self.baseprice
            self.price = y / 100
            self.number = self.box * self.number_in_box

            '''if self.speed_score is None:
                self.speed_score = ...

                self.calculate_speed_score()'''

            # Now we call the actual save method
            super(Product, self).save(*args, **kwargs)
    class Meta:
        ordering = ('name',)
        index_together = (('id', 'slug'),)
    def __str__(self):
        return self.name
    def get_absolute_url(self):
        return reverse('shop:product_detail',args=[self.id, self.slug])
class Comment(models.Model):
    post = models.ForeignKey(Product,
                            on_delete=models.CASCADE,
                            related_name='comments')
    name = models.CharField(max_length=80)
    email = models.EmailField()
    body = models.TextField()
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)
    active = models.BooleanField(default=False)
    class Meta:
        ordering = ('created',)

    def __str__(self):
        return f'Comment by {self.name} on {self.post}'

class Adv (models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='products/Adv/')
    URLL = models.CharField(max_length=200)
    body = models.TextField(blank=True)
    created = models.DateTimeField(auto_now_add=True)
    def __str__(self):
        return self.name

class special(models.Model):
    subject = models.CharField(max_length=50)

class SpecialItem(models.Model):
    special = models.ForeignKey(special,related_name='items',on_delete=models.CASCADE)
    product = models.ForeignKey(Product,related_name='special_items',on_delete=models.CASCADE)
    def __str__(self):
        return str(self.id)

class Gallery(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='gallery/')
    class Meta:
        ordering = ('name',)
        verbose_name = 'گالری'
        verbose_name_plural = 'گالری'

class Points(models.Model):
    name = models.CharField(max_length=50)
    image = models.ImageField(upload_to='points/')
    point = models.CharField(max_length=300,verbose_name = 'نکته')
    class Meta:
        ordering = ('name',)
        verbose_name = 'نکات'
        verbose_name_plural = 'نکات'