from django.urls import path
from . import views
app_name = 'shop'
urlpatterns = [
    path('', views.product_list, name='product_list'),
    path('mahsolat/',views.mahsol_list,name='mahsolat'),
    path('About_us/',views.About_us,name='About_us'),
    path('contact_us/',views.contact_us,name='contact_us'),
    path('search/',views.searchb_us,name='searchr'),
    path('<slug:category_slug>/<str:ti>', views.product_list,name='product_list_by_category'),
    path('<int:id>/<slug:slug>/', views.product_detail,name='product_detail'),
]
