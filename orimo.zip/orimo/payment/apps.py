from django.apps import AppConfig


class PaymentConfig(AppConfig):
    name = 'payment'
