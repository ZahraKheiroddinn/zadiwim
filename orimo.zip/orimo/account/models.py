from django.db import models
from django.conf import settings

class Profile(models.Model):
    item = (('d','D'),('c','C'),('b','B'),('a','A'),)
    sitem=(('public','Public'),('colleague','Colleague'),)
    user = models.OneToOneField(settings.AUTH_USER_MODEL,related_name='profile',on_delete=models.CASCADE)
    grade = models.CharField(max_length = 2, choices=item, default='d')
    status=models.CharField(max_length = 10, choices=sitem, default='public')
    phone = models.CharField(max_length = 11, blank=True)
    adress =models.TextField(max_length = 150, blank=True)
    date_of_birth = models.DateField(blank=True, null=True)
    photo = models.ImageField(upload_to='users/%Y/%m/%d/',blank=True)
    def __str__(self):
        return f'Profile for user {self.user.username}'
