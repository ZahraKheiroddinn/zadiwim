from django.http import HttpResponse
from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth import authenticate, login, logout
from .forms import LoginForm, UserRegistrationForm, UserEditForm, ProfileEditForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
#0033
from .models import Profile
from orders.models import Order
from shop.models import Product
from cart.forms import CartAddProductForm
# Create your views here.

def register(request):
    if request.method == 'POST':
        user_form = UserRegistrationForm(request.POST)
        if user_form.is_valid():
            # Create a new user object but avoid saving it yet
            cd = user_form.cleaned_data
            print(cd)
            if cd['password'] != cd['password2']:
                raise forms.ValidationError('Passwords don\'t match.')
            else:
                new_user = User.objects.create_user(username=cd['username'],first_name=cd['first_name'],email=cd['email'],password=cd['password2'])
                # Set the chosen password

                #new_user.set_password(user_form.cleaned_data['password'])
                # Save the User object
                new_user.save()
                # Create the user profile
                Profile.objects.create(user=new_user)
                user = authenticate(request,username=user_form.cleaned_data['username'],password=user_form.cleaned_data['password'])
                login(request, user)
                return redirect('account:edit')
    else:
        user_form = UserRegistrationForm()
    return render(request,'account/register.html',{'user_form': user_form})


@login_required
def dashboard(request):
    list = []
    userr =request.user
    user_Orders= userr.order.filter(paid=True)
    for i in user_Orders:
        order_item = i.items.filter()
        list.append(order_item)
    return render(request,'account/dashboard.html',{'section': 'dashboard', 'orders':user_Orders, 'item':list})

def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(request,username=cd['username'],password=cd['password'])
            if user is not None:
                flow = get_object_or_404(Profile,user=user)
                status = flow.status
                if status == 'public':
                    if user.is_active:
                        login(request, user)
                        return redirect('shop:product_list')
                    else:
                        return HttpResponse('Disabled account')
                else:
                    form = LoginForm()
                    return render(request, 'account/login.html', {'form': form,'mess':'اکانت شما به همکار ارتقا پیدا کرده از قسمت ورود همکاران اقدام کنید'})
            else:
                return HttpResponse('Invalid login')
    else:
        form = LoginForm()
    return render(request, 'account/login.html', {'form': form})
def colleague_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            user = authenticate(request,username=cd['username'],password=cd['password'])
            if user is not None:
                flow = get_object_or_404(Profile,user=user)
                status = flow.status
                if status == 'colleague':
                    if user.is_active:
                        login(request, user)
                        return redirect('account:profile')
                    else:
                        return HttpResponse('Disabled account')
                else:
                    form = LoginForm()
                    return render(request, 'account/loginh.html', {'form': form,'mess':'اکانت شما به همکار ارتقا نیافه از قسمت ورود اعضا اقدام کنید.'})
            else:
                return HttpResponse('Invalid login')
    else:
        form = LoginForm()
    return render(request, 'account/loginh.html', {'form': form})
@login_required
def logoutuser (request):
    if request.method == 'GET':
            logout(request)
            return redirect('shop:product_list')
#***************003
@login_required
def edit(request):
    if request.method == 'POST':
        user_form = UserEditForm(instance=request.user,data=request.POST)
        profile_form = ProfileEditForm(instance=request.user.profile,
            data=request.POST,
            files=request.FILES)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
    else:
        user_form = UserEditForm(instance=request.user)
        profile_form = ProfileEditForm(instance=request.user.profile)
    return render(request,'account/edit.html',{'user_form': user_form,'profile_form': profile_form})
@login_required
def profile (request):

    userr =request.user
    data= userr.profile
    pro =None
    cart_product_form=None
    if data.status == 'public':
        pass
    elif data.status == 'colleague':
        cart_product_form = CartAddProductForm()
        pro =Product.objects.all()

    return render(request, 'account/profile.html', {'data':data, 'user':userr, 'product':pro,'cart_product_form': cart_product_form})
