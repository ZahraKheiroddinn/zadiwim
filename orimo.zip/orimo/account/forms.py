from django import forms
#*********002
from django.contrib.auth.models import User
#*******003
from .models import Profile
#****


class LoginForm(forms.Form):
    username = forms.CharField (max_length=100, widget=forms.TextInput(attrs={'class':'form-control rounded-pill border-0 shadow-sm px-4', 'placeholder':'نام کاربری' }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={'class':'form-control rounded-pill border-0 shadow-sm px-4 text-danger', 'placeholder':'رمز عبور' }))


#**************002
class UserRegistrationForm(forms.Form):
    password = forms.CharField(label='Password',widget=forms.PasswordInput(attrs={'class':'form-control', 'placeholder':'رمز عبور'}))
    password2 = forms.CharField(label='Repeat password',widget=forms.PasswordInput(attrs={'class':'form-control', 'placeholder':'رمز عبور'}))
    username= forms.CharField (max_length=100, widget=forms.TextInput(attrs={'class':'form-control', 'placeholder':'نام کاربری' }))
    first_name=forms.CharField (max_length=100, widget=forms.TextInput(attrs={'class':'form-control', 'placeholder':'نام و نام خانوادگی' }))
    email = forms.CharField (max_length=100, widget=forms.TextInput(attrs={'class':'form-control', 'placeholder':'ایمیل' }))
    '''class Meta:
        model = User
        fields = ('username', 'first_name', 'email')
    def clean_password2(self):

        if cd['password'] != cd['password2']:
            raise forms.ValidationError('Passwords don\'t match.')
        return cd['password2']
        '''

#******003

class UserEditForm(forms.ModelForm):
    class Meta:
        model = User
        fields = ('first_name', 'last_name', 'email')
class ProfileEditForm(forms.ModelForm):
    class Meta:
        model = Profile
        fields = ('phone','adress','date_of_birth', 'photo')
