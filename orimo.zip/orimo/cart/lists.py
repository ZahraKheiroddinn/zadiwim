public_discont={'a':0.95,'b':0.9,'c':0.85,'d':1}
coleage_discont={'a':0.95,'b':0.9,'c':0.85,'d':1}
